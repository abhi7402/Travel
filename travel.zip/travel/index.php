<!DOCTYPE html>
<html>
<head>
<title></title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
 //function hideURLbar(){ window.scrollTo(0,1); } 
 
 
 </script>
<!--js--> 
<script src="js/jquery.min.js"></script>

</head>
<body>
<!--header-->
<!--sticky-->
<?php include('function.php'); ?>

<?php include('top.php'); ?>
<!--/sticky-->
<?php include('slider.php'); ?>
<!--About-->
     <div class="about section" id="section-2">
	  <div class="about-head text-center">
	  <h3>About Us</h3>
	  </div>
	   <div class="container">		  
		 <div class="col-md-4 about-grids">
			 <h4>Our Vision</h4>
			 <p>Our vision for a tours and travels website is to provide an all-inclusive platform that empowers users to explore the world with ease,
convenience, and safety. We aim to become the go-to destination for travelers seeking personalized and curated travel experiences.
Our website will offer a user-friendly interface that caters to the needs of both novice and seasoned travelers.
We will provide a comprehensive range of services, including flight bookings, hotel reservations, car rentals,
and tours and activities, among others.We envision our tours and travels website as a one-stop-shop for travelers,
 where they can plan,book, and manage their trips all in one place. Our commitment to safety and security will be paramount, 
and we will ensure that all our partners and vendors meet our stringent safety and quality standards.</p></div>
		 <div class="col-md-4 about-grids grid2">
			 <h4>Our Mission</h4>
			 <p>
Our mission for our tours and travels website is to provide our users with the most comprehensive, personalized, and hassle-free travel experience. We strive to empower travelers with the knowledge, tools, and resources they need to make informed decisions and create unforgettable memories.We are also committed to promoting sustainable and responsible travel practices. Our mission is to encourage travelers to be mindful of their impact on the environment, culture, and local communities they visit. We aim to work with local businesses and support sustainable tourism initiatives to create a positive impact on the destinations we serve.

Overall, our mission for our tours and travels website is to inspire and enable travelers to explore the world, make meaningful connections, and create unforgettable experiences while upholding high standards of safety, quality, and sustainability.</p></div>
		 <div class="col-md-4 about-grids">
			 <h4>Safety Information</h4>
			 <p>
Welcome to our tours and travels website! We want to ensure that you have a safe and enjoyable travel experience, so please read the following safety information before booking your trip:

Check travel advisories: Before booking your trip, check travel advisories issued by your government and other relevant authorities. These advisories provide important information about safety and security concerns in your destination.

Purchase travel insurance: We strongly recommend purchasing travel insurance that includes coverage for medical emergencies, trip cancellations, and other unexpected events. Make sure to carefully review the terms and conditions of your policy.

Keep important documents safe: Keep your passport, travel itinerary, and other important documents in</p></div>
	 </div>
</div>
<!--/About-->
<!--top-tours-->	
<div  class="section" id="section-3">
<div id="portfolio" class="portfolio">
   <div class="top-tours-head text-center">
		  <h3>Gallery</h3>		 
		  </div>
	      <ul id="filters" class="clearfix wow bounceIn" data-wow-delay="0.4s">
			<li><span class="filter active" data-filter="app card icon logo fun"><a href="#home_section">ALL</a>
</span></li>

			<li id="home_section"><span class="filter" data-filter="app"><a href="https://www.airindia.in/Domestic-Travel.htm"> Domestic Travel </a></span></li>
			<li id="home_section"><span class="filter" data-filter="card"><a href="https://www.gousa.in/?gclsrc=aw.ds&&utm_source=goog&gad=1&utm_medium=td&utm_campaign=sh&utm
			_content=at&utm_term=prospec&fy23_in_int_gen_getr_sem_pd_destvacays&gclid=CjwKCAjwjMiiBhA4EiwAZe6jQ-vB1JRzUEOqObfAs5qRsYm8JoD6rpQmYVz7VonffRTPozM4d
			HrO7hoCyooQAvD_BwE">Foreign Travel</a></span></li>
			<li id="home_section"><span class="filter" data-filter="icon"><a href="https://www.holidify.com/collections/short-trips-in-india">Short Date Tour</a></span></li>
			<li id="home_section"><span class="filter" data-filter="fun"><a href="https://www.longlivemontero.com/">Long Date Tour</a></span></li>
	        </ul>
	     <div id="portfoliolist">
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t1.jpg" class="img-responsive" alt=""/></a>
							</div>
					</div>				
					<div class="portfolio app mix_all" data-cat="app" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t2.jpg" class="img-responsive" alt=""/></a>
                             </div>
					</div>		
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t3.jpg" class="img-responsive" alt=""/></a>
							
					</div>
					</div>				
					<div class="portfolio icon mix_all" data-cat="icon" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t4.jpg" class="img-responsive" alt=""/></a>
							 
						</div>
					</div>	
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t5.jpg" class="img-responsive" alt=""/></a>
							 
						</div>
					</div>			
					<div class="portfolio fun mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t6.jpg" class="img-responsive" alt=""/></a>
							
						</div>
			      </div>
				  <div class="portfolio fun mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
							<img src="images/t7.jpg" class="img-responsive" alt=""/></a>
							
						</div>
			      </div>
				  <div class="portfolio icon mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="images/t8.jpg" class="img-responsive" alt=""/></a>
							 
					   </div>
			      </div>
		   <div class="clearfix"></div>	
	  </div>
</div>
</div>  

<!--/top-tours-->

<div id="section-5" class="contact section">
	  <div class="contact-head text-center">
		  <h3>Contact Us</h3>
		  <br>
		  <h4 style="color:#000">Plan Your Trip</h4>
		  <br>
		  <h5 style="color:#000">Our travel experts can help you book now</h5>

		  <div class="contact-grids">
			  <div class="container">
				  <div class="col-md-4 address">
						<h4 style="color:#09F"></h4>
						<p style="color:#000"><br/>
                        </p>
                        <br/>
                      </div>
				  <div class="col-md-8 contact">
                  
                  	<?php
if(isset($_POST["sbmt"]))
{
	$cn=makeconnection();
	$s="insert into contactus(Name,Phno,Email,Message) values('" . $_POST["t1"] ."','" . $_POST["t2"] ."','" . $_POST["t3"] ."','" . $_POST["t4"] ."')";
	mysqli_query($cn,$s);
	mysqli_close($cn);
	echo "<script>alert('Record Save');</script>";
}
?>
					  <form method="post">
                      <table border="0" width="700px" height="500px">
                      <tr><td align="left"> <input type="text" class="text" value=" Name"  name="t1" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your Name';}" required pattern="[a-zA-z1 _]{1,50}" title"Please Enter Only Characters and numbers between 1 to 50 for Name"></td></tr>
                      <tr><td align="left"><input type="text" class="text" value=" Contact No" name="t2" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your Contact NO';}" required pattern="[0-9]{10,12}" title"Please Enter Only  numbers between 10 to 12 for Contact no"></td></tr>
					 <tr><td align="left"> <input type="text" class="text" value="Email" name="t3" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your mail';}" required></td></tr>
					 <tr><td><textarea onFocus="if(this.value == 'Message') this.value='';" name="t4" onBlur="if(this.value == '') this.value='Enter Message Here';" required/ >Message</textarea></td></tr>
					  <tr><td><input type="submit" value="Send message" name="sbmt"></td></tr></table>
					  <div class="clearfix"></div>
					   </form>
				   </div>
				  <div class="clearfix"></div>
			  </div>
		  </div>
	       



<?php include('bottom.php'); ?>
</body>
</html>

